## Module <om_hr_payroll_account>

#### 08.04.2022
#### Version 15.0.4.0.0
##### IMP
- cancel payslip

#### 16.02.2022
#### Version 15.0.3.0.0
##### IMP
- enhancements

#### 01.02.2022
#### Version 15.0.2.1.0
##### FIX
- journal account
