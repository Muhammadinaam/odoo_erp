# See LICENSE file for full copyright and licensing details

from . import change_attendance_data