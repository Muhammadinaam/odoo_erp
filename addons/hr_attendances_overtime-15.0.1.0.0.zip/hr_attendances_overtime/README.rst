=======================
HR Attendance Policies
=======================

This module is provided a feature to Calculate Overtime, Absence And Time Delay.
Create PaySlip Depends on Attendance policies Rules Configure.


=========	
Features
=========

Attendance Rules :-

 * Overtime Rules
   - You can configure the Overtime rule for weekday, weekend and public holiday.
   - Every rule has it period on which overtime get calculate only after period.
   - Every rule has it own rate that is used to calculate overtime hourly rate.

 * Late-In Rules
   - Configure the Late-in rules with multiple steps of periods.
   - Every lateness step has it`s type and rates to be calculated on payslip.

 * Absence Rules
   - Configurable Absence rules with multiple steps to calculated base no of days absence 
     during payslip duration.
   - Every Absence Step has it`s rate to be calculated on payslip.
   
Attendance Policies :-

- You can create the attendance Policies that contain all rules to assigned to employee.
- Select the attendance policies in employee contract.

Attendance Sheet :-

- Attendance sheet contain the calculated attendance data for the selected employee within the 
  selected period.

Create Payslip From Attendance Sheet :-

- Create the payslip from the attendance sheet that contains the attendance data to calculate 
  the payslip related to attendance rule.


============
Similar Apps
============

HR Attendance Policies
hr attendance sheet and policies 
hr attendance policy
hr policies for attendance
hr policies on attendance
hr attendance policy system
hr attendance policy template    
Attendance Policies
hr attendance Rules
hr attendance Sheet
hr attendance
Human Resource Attendance Reports
