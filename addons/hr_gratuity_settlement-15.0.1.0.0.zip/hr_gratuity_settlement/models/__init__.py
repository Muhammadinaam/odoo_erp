# -*- coding: utf-8 -*-
from . import gratuity_configuration
from . import hr_gratuity
from . import gratuity_accounting_configuration
from . import hr_employee
from . import hr_leave
from . import hr_training
from . import hr_contract
